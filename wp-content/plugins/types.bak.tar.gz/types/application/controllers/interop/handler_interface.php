<?php

/**
 * Interface Types_Interop_Handler_Interface
 *
 * See Types_Interop_Mediator for details.
 *
 * @since 2.2.7
 */
interface Types_Interop_Handler_Interface {

	public static function initialize();

}