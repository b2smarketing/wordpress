=== Mega Addons For WPBakery Page Builder (formerly Visual Composer) ===
Contributors: nasir179125
Donate link: http://paypal.me/webcodingplace
Tags: mega addons for wpbakery page builder, mega addons for visual composer, wpbakery page builder, visual composer, all in one plugin, visual composer extension, multi addons for visual composer, imag hover effects, visual composer addons, vc addons, visual composer extensions, vc extensions, page builder, portfolio, carousel, post, posts, shortcodes, tabs, admin, plugin, page, member profile, info banner, price table, stats counter, flip book, testimonial
Requires at least: 3.5
Tested up to: 5.1
Stable tag: 3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

28 Addons visual composer extension, Beautifully designed unique elements, Includes Premium quality addons For WPBakery Page Builder.

== Description ==

<blockquote>
    <p>
        <strong>Best Addons Plugin For WPBakery Page Builder - WordPress Plugin</strong>
    </p>
</blockquote>
<p>
	<strong>Notice: This update is a major release. Designs made in some themes may effect. In case, you can get old version back by <a href="https://www.topdigitaltrends.net/mega-addons-for-visual-composer-2.3.zip">clicking here</a> for backward compatibility. 1) First delete the new version. 2) Upload the old version 2.3 and activate It. For more info, please <a href="https://www.topdigitaltrends.net/contact/">contact us</a></strong>
</p>
Mega Addons For Visual Composer ~ The biggest Addon bundle for Visual Composer With 28 addons. This Addon Bundle provide you everything for your Visual Composer Page Builder. Addons for Visual Composer features professional looking, easy to use yet highly functional extensions that can be used in a WPBakery Visual Composer page builder.<br>
<a href="https://codecanyon.net/item/visual-composer-page-builder-for-wordpress/242431?ref=nasir179125"><strong>WPBakery Page Builder (formerly Visual Composer)</strong></a> plugin must be installed and activated to use this plugin. After you activate the required plugins, the elements should be available for use in Visual Composer.

<blockquote>
<p><a href="http://addons.topdigitaltrends.net/addons/" rel="nofollow">Live Demo </a> | <a href="http://www.topdigitaltrends.net/contact/" rel="nofollow">Contact</a> | <a href="https://wordpress.org/support/plugin/mega-addons-for-visual-composer" rel="nofollow">Support forum</a> | <a href="http://addons.topdigitaltrends.net/documentation/" rel="nofollow">How To Use</a> | <a href="http://www.topdigitaltrends.net/blog/" rel="nofollow">Blog</a></p>
</blockquote>
<p><strong>If you like this plugin, please give us <a href="https://wordpress.org/support/plugin/mega-addons-for-visual-composer/reviews/#new-post" rel="nofollow">5 star</a> to encourage for future improvement.</strong></p>

<h3>Features</h3>
<ul>
	<li><a href="http://addons.topdigitaltrends.net/member-profile/">Member Profile</a> Show your awesome team</li>
	<li><a href="http://addons.topdigitaltrends.net/info-banner/">Info Banner</a> Displays the banner information</li>
	<li><a href="http://addons.topdigitaltrends.net/image-hover-effects/">Image Hove Effects</a> Image Hover Effects</li>
	<li><a href="http://addons.topdigitaltrends.net/interactive-banner/">Interactive Banner</a> great hover effects</li>
	<li><a href="http://addons.topdigitaltrends.net/interactive-banner-2/">Interactive Banner 2</a> Display Image With Information</li>
	<li><a href="http://addons.topdigitaltrends.net/price-table/">Price Table</a> Create nice looking price tables</li>
	<li><a href="http://addons.topdigitaltrends.net/advanced-pricing-list/">Price Table Listing</a> Compare Listing</li>
	<li><a href="http://addons.topdigitaltrends.net/post-carousel/">Post Carousel/Grid</a> Show posts as carousel</li>
	<li><a href="http://addons.topdigitaltrends.net/stats-counter/">Stats Counter</a> Your milestones, achievements etc</li>
	<li><a href="http://addons.topdigitaltrends.net/info-box/">Info Box</a> Add icon box with custom font icon</li>
	<li><a href="http://addons.topdigitaltrends.net/carousal-slider/">Caousal Slide</a> Show as carousel</li>
	<li><a href="http://addons.topdigitaltrends.net/flip-box/">Flip Box</a> Add icon box with custom font icon</li>
	<li><a href="http://addons.topdigitaltrends.net/image-hover-effects-popup-demo/">Modal Popup For Image Hover Effects</a> Image Hover Effects</li>
	<li><a href="http://addons.topdigitaltrends.net/flip-book/">Flip Book</a> 3D Page Flip Book</li>
	<li><a href="http://addons.topdigitaltrends.net/advanced-button/">Advanced Button</a> Animated style buttons</li>
	<li><a href="http://addons.topdigitaltrends.net/dual-button/">Dual Button</a> Add a dual button and give some desing</li>
	<li><a href="http://addons.topdigitaltrends.net/timeline/">Timeline</a> Add multiple images and text</li>
	<li><a href="http://addons.topdigitaltrends.net/creative-link/">Creative Link</a> Creative links button</li>
	<li><a href="http://addons.topdigitaltrends.net/countdown/">Countdown</a> Set Countdown timer</li>
	<li><a href="http://addons.topdigitaltrends.net/advanced-social-icons/">Advanced Social Icons</a> social icons with animated effects</li>
	<li><a href="http://addons.topdigitaltrends.net/texttype-effects/">TextType</a> Fancy line with animation effects</li>
	<li><a href="http://addons.topdigitaltrends.net/modal-popup/">Modal Popup</a> Add modal box in your content</li>
	<li><a href="http://addons.topdigitaltrends.net/info-list/">Info List</a> Text blocks connected together in one list</li>
	<li><a href="http://addons.topdigitaltrends.net/google-trends/">Google Trends</a> show google trends</li>
	<li><a href="http://addons.topdigitaltrends.net/tooltip-icons/">Tooltip Icons</a> show icons with tooltip</li>
	<li><a href="http://addons.topdigitaltrends.net/testimonial/">Testimonial</a> show client comments as testimonial</li>
	<li><a href="http://addons.topdigitaltrends.net/headings/">Headings</a> Display stylish headings</li>
	<li><a href="http://addons.topdigitaltrends.net/highlight-box/">Highlight Box</a> Beautiful designed buttons for highlight</li>
	<li><a href="http://addons.topdigitaltrends.net/image-swap/">Image Swap</a> Image over image hover effects</li>
	<li><a href="http://addons.topdigitaltrends.net/accordion/">Accordion</a> vertically stacked list of items</li>
	<li><a href="http://addons.topdigitaltrends.net/info-circle/">Info Circle</a> express info about your work</li>
	<li><a href="http://addons.topdigitaltrends.net/before-after-image/">Before After Image</a> Compare the Images</li>
</ul>

<blockquote>
    <h3>
        <strong>Top Rated Collection Of Plugins and Themes 2018</strong>
    </h3>
</blockquote>
<ul>
	<li><a href="http://www.topdigitaltrends.net/collections/20-best-personal-blog-wordpress-themes-2018/">20 Best Personal Blog WordPress Themes 2018</a></li>
	<li><a href="http://www.topdigitaltrends.net/collections/top-20-wordpress-review-themes-for-e-gadgets-services-apps-games-2018/">Top 10+ Best Review WordPress Themes 2018</a></li>
	<li><a href="http://www.topdigitaltrends.net/collections/10-best-nightclub-wordpress-themes-2018/">10 Best Nightclub WordPress Themes 2018</a></li>
</ul>

== Installation ==

1. Go to plugins in your dashboard and select 'add new'
2. Search for 'Mega Addons For Visual Composer' and install it.
3. Go To pages and create design with help of viusal composer page builder.
4. Fill some additional informations.
5. Now visit your site

== Frequently Asked Questions ==

= I activated the Mega Addons Plugin but I cannot see It In the dashboard pannel? =

It is the extension of <a href="https://codecanyon.net/item/visual-composer-page-builder-for-wordpress/242431?ref=nasir179125">WPBakery Page Builder (formerly Visual Composer)</a> so you must have visual composer plugin to use my plugin. It works with Visual Composer Page Builder. After you activate the required plugins, the elements should be available for use in Visual Composer.

= How To add background image in Info Banner? =

Select background image from "Design Options" category. You can see Its demo at the end of page http://addons.topdigitaltrends.net/info-banner/


= Activating plugin causes "500 server error" =

Let’s take a look at how to go about troubleshooting the internal server error in WordPress. It may solve the problem.
https://www.youtube.com/watch?time_continue=387&v=Qj4tfvMlcJs

== Screenshots ==


== Changelog ==

= 3.1 =
* This verion have some changes In settings so please make sure to backup your previous version and design. Your design can be change on updating the plugin so first test It on other server or localhost.
* These settings will effect on font size, padding, height width and URL given to elements.
* If you update the plugin by mistaken then simply revert the old version 2.3 and settings will be back. You can download It from Plugin URI on WordPress.org
* Now you can disable unused elements from dashboard to speed up your page loading time.
* We fixed too much bugs in new version and made more responsive design.
* You can add custom settings for mobile devices.
* Info Box: Addition of WP-Editor option for description field and Box shadow and "Link To" options.
* Accordion: Options of Collapseable + animation + mouseover and clickable, plus panel height issue resolved.
* Addition: Width & Height option for Image Hover Effects.
* Image Alt attribute In all elements.
* Remove "Photobook" element.
* Flip Box CSS fixed rotation problem
* Price Table: 2 more design.
* Addition: Text Color & background color onhover for button in modal popup element.
* Addition: Border Style option in Image Swap Element.
* Extra Spaces Removed From Interactive Banner Design.

= 2.3 =
* In this version we are just letting you know that a new beta version 3.0 will be release soon which will have alot of changes so please make sure to backup your previous version. You can download the Beta version from given link:- https://addons.topdigitaltrends.net/mega-addons-beta-version/


= 2.2 =
* Bug Fixed: Info banner mobile responsive issue
* Bug Fixed: Modal Popup play randomly video onClick.
* Remove: Flip Box bold heading
* <a href="http://www.topdigitaltrends.net/mega-addons-visual-composer-wordpress-plugin/">Pro Version</a> available with much more options and designs.
* In pro version, you can disable unused elements from dashboard to speed up your page loading time.

= 2.1 =
* Fixed: Info banner mobile responsive issue
* Added: Add link to image in member profile
* Changes: Price Table setting changes
* Fixed: Some Bugs 

= 2.0 =
* Notice: Please make sure to backup your previous version. This update has a large amount of changes and many new features are added. Feel free to ask on support forum regarding any issues before leaving a low star rating. Thanks 

= 1.0 =
* First Version