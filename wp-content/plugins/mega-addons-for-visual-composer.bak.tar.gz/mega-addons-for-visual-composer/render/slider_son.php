<li>
  	<img style="height: <?php echo $height; ?>; width: 100%;" src="<?php echo $image_url; ?>" />
		<div class="slider-content <?php echo $css_class; ?>" style="top: 0;">
	  	<?php echo $content; ?>
	</div>
</li>